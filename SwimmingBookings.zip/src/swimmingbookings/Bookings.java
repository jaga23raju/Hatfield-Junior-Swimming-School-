
package swimmingbookings;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class Bookings {
    
    
    private String bookingID;
    private int userID;
    private int timetableID;
    private String bookingStatus;
    private int instructedBy;
    
    public static List <Bookings> bookingData = new ArrayList<>();
    
    public static String TEMPORARY_BOOKING_ID = "";
    public static boolean BOOKING = false;
    public static boolean CHANGE_BOOKING = false;
    
      
    public static final String BOOKED = "Booked";
    public static final String CHANGED = "Changed";
    public static final String CANCELLED = "Cancelled";
    public static final String ATTENDED = "Attended";
    
    

    public Bookings(String bookingID, int userID, int timetableID, String bookingStatus, int instructedBy) {
        this.bookingID = bookingID;
        this.userID = userID;
        this.timetableID = timetableID;
        this.bookingStatus = bookingStatus;
        this.instructedBy = instructedBy;
    }

    public String getBookingID() {
        return bookingID;
    }

    public int getUserID() {
        return userID;
    }

    public int getTimetableID() {
        return timetableID;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public int getInstructedBy() {
        return instructedBy;
    }

    public static List<Bookings> getBookingData() {
        return bookingData;
    }

    public void setTimetableID(int timetableID) {
        this.timetableID = timetableID;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public void setInstructedBy(int instructedBy) {
        this.instructedBy = instructedBy;
    }
    
    //scheduleBooking
    public static void scheduleBooking(int timetableID){
        int learnerID = Users.LOGGED_IN_ID;
        
        Random random = new Random();
        int num = random.nextInt(900) + 100;
        
        String bookingID = "BNum"+learnerID+num;
        
        //get lesson id
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();
        
        int instructorID = 0;
        for(TimetableLessons obj : timetableLessons){
            if(obj.getTimetableID() == timetableID){
                instructorID = obj.getInstructorUserID();
                break;
            }
        }
       
        Bookings bookingObj = new Bookings(bookingID,learnerID,timetableID,BOOKED,instructorID);
        Bookings.bookingData.add(bookingObj);
        
        Bookings.TEMPORARY_BOOKING_ID = bookingID;

        //Update max seats 
        TimetableLessons.decreaseLessonSeatsAvailability(timetableID);
    }
    
    
    //updateBooking
    public static void updateBooking( int timetableID){
          
        List<Bookings> bookings = Bookings.getBookingData();

        int oldTimetableID = 0;
        for(Bookings obj : bookings){
            if(obj.getBookingID().equalsIgnoreCase(Bookings.TEMPORARY_BOOKING_ID)){
                oldTimetableID = obj.getTimetableID();
                break;
            }
        }
         
        //Get timetable ID
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();
        int instructorID = 0;
        for(TimetableLessons obj : timetableLessons){
            if(obj.getTimetableID() == timetableID){
                instructorID = obj.getInstructorUserID();
                break;
            }
        }
  
        //Update booking status
        for(Bookings obj : bookings){
            if(obj.getBookingID().equalsIgnoreCase(Bookings.TEMPORARY_BOOKING_ID)){
                obj.setBookingStatus(CHANGED);
                obj.setTimetableID(timetableID);
                obj.setInstructedBy(instructorID);
                break;
            }
        }
        
               
        //increaseLessonSeatsAvailability
        TimetableLessons.increaseLessonSeatsAvailability(oldTimetableID);
        
         //decreaseLessonSeatsAvailability
        TimetableLessons.decreaseLessonSeatsAvailability(timetableID);
        
    }
    
    
    //continueBooking
    public static void continueBooking(){
        Scanner scanner = new Scanner(System.in);
        
        //User ID
        System.out.print("\nPlease Enter User ID from above list : ");
        String userID = scanner.nextLine();
        
        
        if(userID.equalsIgnoreCase("") || !MainClass.checkDigit(userID)){
            do{
                System.out.print("\nPlease Enter Valid UserID : ");
                userID = scanner.nextLine();
            }while(userID.equalsIgnoreCase("") || !MainClass.checkDigit(userID));
        }
        
        boolean existUser = Users.isUserFound(Integer.parseInt(userID));
        
        if(!existUser){
            System.out.print("\nUserID was not found. ");
            return;
        }
        
        //Privacy Code
        System.out.print("\nPlease Enter Password : ");
        String privacyCode = scanner.nextLine();
        
        if(privacyCode.equalsIgnoreCase("")){
            do{
                System.out.print("\nPlease Enter Password : ");
                privacyCode = scanner.nextLine();
            }while(privacyCode.equalsIgnoreCase(""));
        }
        
        boolean existPrivacyCode = Users.passwordFound(privacyCode,Integer.parseInt(userID));
        
        if(!existPrivacyCode){
            System.out.print("\nPassword was not found ");
            return;
        }
        
        //Save User details
        Users.LOGGED_IN_ID = Integer.parseInt(userID);
        
        //get user role
        String role = Users.getUserRoleOfLoggedInUser(Integer.parseInt(userID));
        
        System.out.println("\nYou can Use below functions : ");
        
        //Learner Menu
        if(role.equalsIgnoreCase("Learner")){
            int selectedOption;
            do {
                selectedOption = MenuClass.learnerMenu();
                switch (selectedOption) {
                    case 1 -> TimetableLessons.viewTimetableLessons();
                    case 2 -> MenuClass.manageBookings();
                    case 3 -> InstructorRatings.givenRatings();
                    case 4->{
                                System.out.println("\n-------------------------------------");
                                System.out.println("\tSigned Out");
                                Users.LOGGED_IN_ID = 0;
                                return;
                            }
                    default -> System.out.println("\nPlease Select Valid Choice : ");
                }
            } while (selectedOption != 4);
        //Staff Functions
        }else{
            int selectedOption;
            do {
                selectedOption = MenuClass.staffMenu();
                switch (selectedOption) {
                    case 1 -> Users.addUser();
                    case 2 -> TimetableLessons.viewTimetableLessons();
                    case 3 -> Bookings.viewBookedLessons();
                    case 4 -> InstructorRatings.givenRatings();
                    case 5 -> Users.viewUsers();
                    case 6 -> {
                                ProxyDesignPatttern ratingReportProxy = new ProxyDesignPatttern();
                                ratingReportProxy.generateReport();
                              }
                    case 7 ->{
                                System.out.println("\nX-------------------------------------X");
                                System.out.println("\tSigned Out from the System");
                                System.out.println("X-------------------------------------X");
                                Users.LOGGED_IN_ID = 0;
                                return;
                            }
                    default -> System.out.println("\nPlease Select Valid Choice : ");
                }
            } while (selectedOption != 7);
        }
    }
     
    
    
    //Cancel Class
    public static void cancelBooking(){
        
        //Already Atteded
        boolean isBookingAlreadyAttendedByLearner = Bookings.isBookingAlreadyAttendedByLearner(Bookings.TEMPORARY_BOOKING_ID);
        if(isBookingAlreadyAttendedByLearner){
            System.out.println("\nAlready Attended Lesson");
            return;
        }
        
        //Already cancelled
        boolean isBookingAlreadyCancelByLearner = Bookings.isBookingAlreadyCancelByLearner(Bookings.TEMPORARY_BOOKING_ID);
        if(isBookingAlreadyCancelByLearner){
            System.out.println("\nAlready Cancelled Lesson");
            return;
        }
        
        List<Bookings> bookings = Bookings.getBookingData();

        int timetableID = 0;
        for(Bookings obj : bookings){
            if(obj.getBookingID().equalsIgnoreCase(Bookings.TEMPORARY_BOOKING_ID)){
                timetableID = obj.getTimetableID();
                obj.setBookingStatus(CANCELLED);
                break;
            }
        }
        
        //increaseLessonSeatsAvailability
        TimetableLessons.increaseLessonSeatsAvailability(timetableID);
        
        System.out.println("\nSuccess : Cancelled");
    }
    
    
    //View Booked Class
    public static void viewBookedLessons(){
        
        System.out.println("\n\n--------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-10s | %-10s | %-12s | %-15s | %-10s | %-10s | %-20s | %-18s | %-15s | %-12s | \n",
                "BookingID","TimetableID","Lesson", "LessonGrade","WeekDay","Slot", "InstructedBy","BookedBy",
                "LearnerGrade","Status");
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        
        List<Bookings> bookings = Bookings.getBookingData();
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();
        List<Users> users = Users.getUsersData();
        
        //Get logged user role
        String role = "";
         for(Users userObj : users ){
            if(userObj.getUserID() == Users.LOGGED_IN_ID){
                role = userObj.getUserType();
                break;
            }
        }
        
        Set<String> uniqueRows = new HashSet<>(); 
        
        for(Bookings obj : bookings){
            if(!uniqueRows.contains(obj.getBookingID())){
                
                //Lessons
                String lessonName = "";
                String time = "";
                String day = "";
                int classgrade = 0;
                for(TimetableLessons timetableObj : timetableLessons ){
                    if(timetableObj.getTimetableID() == obj.getTimetableID()){
                        lessonName = timetableObj.getLesson();
                        time = timetableObj.getSlot();
                        day = timetableObj.getDay();
                        classgrade = timetableObj.getClassGradelevel();
                        break;
                    }
                }
                //Learner
                String bookedBy = "";
                int learnerGrade = 0;
                for(Users userObj : users ){
                    if(userObj.getUserID() == obj.getUserID()){
                        bookedBy = userObj.getUsername();
                        learnerGrade = userObj.getGradeLevel();
                        break;
                    }
                }
                //Coach
                String instructor = "";
                for(Users userObj : users ){
                    if(userObj.getUserID() == obj.getInstructedBy()){
                        instructor = userObj.getUsername();
                        break;
                    }
                }
                uniqueRows.add(obj.getBookingID());
                
                if(role.equalsIgnoreCase("learner")){
                    if(obj.getUserID() == Users.LOGGED_IN_ID){
                        System.out.printf("| %-10s | %-10s | %-12s | %-15s | %-10s | %-10s | %-20s | %-18s |  %-15s | %-12s | \n",
                        obj.getBookingID(),obj.getTimetableID(),lessonName, classgrade,day,time, 
                        instructor,bookedBy,
                        learnerGrade,obj.getBookingStatus());
                    }
                }else{
                    System.out.printf("| %-10s | %-10s | %-12s | %-15s | %-10s | %-10s | %-20s | %-18s | %-15s | %-12s | \n",
                    obj.getBookingID(),obj.getTimetableID(),lessonName, classgrade,day,time, instructor,bookedBy,
                    learnerGrade,obj.getBookingStatus());
                }
            }
        }
        
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        
    }
    

    //Is booking id exists
    public static boolean isBookingIDFound(String bookingID){
        boolean found = false;
        
        List<Bookings> bookings = Bookings.getBookingData();

        for(Bookings obj : bookings){
            if(obj.getBookingID().equalsIgnoreCase(bookingID)){
                found = true;
                break;
            }
        }
        return found;
    }
    

    //returnBookingTimetableID
    public static int returnBookingInstructorID(){
        int instructorID = 0;
        
        List<Bookings> bookings = Bookings.getBookingData();

        for(Bookings obj : bookings){
            if(obj.getBookingID().equalsIgnoreCase(Bookings.TEMPORARY_BOOKING_ID)){
                instructorID = obj.getTimetableID();
                break;
            }
        }
        return instructorID;
    }
    
     
    //Is attended booking
    public static boolean isBookingAlreadyAttendedByLearner(String bookingID){
        boolean found = false;
        
        List<Bookings> bookings = Bookings.getBookingData();

        for(Bookings obj : bookings){
            if(obj.getBookingID().equalsIgnoreCase(bookingID) && obj.getBookingStatus().equalsIgnoreCase(ATTENDED)){
                found = true;
                break;
            }
        }
        return found;
    }
    
     
    //Is cancelled booking
    public static boolean isBookingAlreadyCancelByLearner(String bookingID){
        boolean found = false;
        
         List<Bookings> bookings = Bookings.getBookingData();

        for(Bookings obj : bookings){
            if(obj.getBookingID().equalsIgnoreCase(bookingID) && obj.getBookingStatus().equalsIgnoreCase(CANCELLED)){
                found = true;
                break;
            }
        }
        return found;
    }
    
     
    //Is Duplicate booking
    public static boolean isBookingTwiceByLearner(int timetableID){
        boolean found = false;
        
        int LOGGED_IN_ID = Users.LOGGED_IN_ID;
        
        List<Bookings> bookings = Bookings.getBookingData();

        for(Bookings obj : bookings){
            if(obj.getUserID() == LOGGED_IN_ID && obj.getTimetableID() == timetableID && (obj.getBookingStatus().equalsIgnoreCase(BOOKED) ||
                    obj.getBookingStatus().equalsIgnoreCase(CHANGED))){
                found = true;
                break;
            }
        }
        return found;
    }
    
    
    
}
