
package swimmingbookings;

import java.util.List;
import java.util.Scanner;


public class MenuClass {
    
    
    
    //Options
    public static int mainMenuOptions(){
         Scanner scanner = new Scanner(System.in);
        Users.viewUsers();

        System.out.println("\n\nSelect Choice from below options : \n");
        System.out.println("1/ Select Your User ID from above list to continue booking ");
        System.out.println("2/ Exit");
        System.out.print("\nYour Choice : ");

        String selected = scanner.nextLine();
        while (selected.equals("") || !MainClass.checkDigit(selected))
        {
            System.out.print("\nPlease Select Valid Choice : ");
            selected = scanner.nextLine();
        }
        return Integer.parseInt(selected);
    }
    
    
     
    //Learner Menu
    public static int learnerMenu(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n\nSelect Choice from below options : \n");
        System.out.println("1/ Timetable");
        System.out.println("2/ Manage Booking");
        System.out.println("3/ Added Reviews");
        System.out.println("4/ SignOut");
        System.out.print("\nYour Choice : ");

        String selected = scanner.nextLine();
        while (selected.equals("") || !MainClass.checkDigit(selected))
        {
            System.out.print("\nPlease Select Valid Choice : ");
            selected = scanner.nextLine();
        }
        return Integer.parseInt(selected);
    }
    

    //Staff Menu
    public static int staffMenu(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n\nSelect Choice from below options : \n");
        System.out.println("1/ Add Learner");
        System.out.println("2/ Timetable");
        System.out.println("3/ Booking");
        System.out.println("4/ Ratings");
        System.out.println("5/ Registered Learners");
        System.out.println("6/ Reports");
        System.out.println("7/ SignOut");
        System.out.print("\nYour Choice : ");

        String selected = scanner.nextLine();
        while (selected.equals("") || !MainClass.checkDigit(selected))
        {
            System.out.print("\nPlease Select Valid Choice : ");
            selected = scanner.nextLine();
        }
        return Integer.parseInt(selected);
    }

    

    //applyFilterOnTimetableLessonOption
    public static int applyFilterOnTimetableLessonOption(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n\nMake Choice from below menu options to apply filter on above timetable : \n");
        System.out.println("1/ Instructor");
        System.out.println("2/ Day");
        System.out.println("3/ Grade Level");
        System.out.println("4/ Go To Home");
        System.out.print("\nYour Choice : ");

        String option = scanner.nextLine();
        while (option.equals("") || !MainClass.checkDigit(option))
        {
            System.out.print("\nPlease Select Valid Choice : ");
            option = scanner.nextLine();
        }
        return Integer.parseInt(option);
    }
    
     
    //applyFilterOnTimetableLesson
    public static void applyFilterOnTimetableLesson(){
        
       int option;
        do {
            option = applyFilterOnTimetableLessonOption();
            switch (option) {
                case 1 -> {
                            TimetableLessons.inputInstructorIdToApplyFilter();
                            return;
                          }
                case 2 -> {
                            TimetableLessons.inputDayToApplyFilter();
                            return;
                          }
                case 3 -> {
                            TimetableLessons.inputGradeLevelToApplyFilter();
                            return;
                          }
                case 4 ->{
                            return;
                        }
                default -> System.out.println("\nPlease Select Valid Choice : ");
            }
        } while (option != 4);       
    }
   
 
     //manageBookings
    public static int bookingsOptions(){
        Scanner scanner = new Scanner(System.in);

        int currentGradeLevel = 0;
                
        List<Users> users = Users.getUsersData();
        
        for(Users obj : users){
            if(obj.getUserID() == Users.LOGGED_IN_ID){
                currentGradeLevel = obj.getGradeLevel();
                break;
            }
        }
        
        System.out.println("\n\nMake Choice from below menu : \n");
        System.out.println("1/ Book Lesson (Current Grade Level : "+currentGradeLevel+")");
        System.out.println("2/ Change");
        System.out.println("3/ Cancel");
        System.out.println("4/ Attend");
        System.out.println("5/ View");
        System.out.println("6/ Go To Home");
        System.out.print("\nYour Choice : ");

        String selected = scanner.nextLine();
        while (selected.equals("") || !MainClass.checkDigit(selected))
        {
            System.out.print("\nPlease Select Valid Choice : ");
            selected = scanner.nextLine();
        }
        return Integer.parseInt(selected);
    }
    
    
    //bookingsOptions
    public static void manageBookings(){
        
       int selectedOption;
        do {
            selectedOption = bookingsOptions();
            switch (selectedOption) {
                case 1 ->{
                            Bookings.BOOKING = true;
                            TimetableLessons.viewTimetableLessons();
                            Bookings.BOOKING = false;
                            return;
                         }
                case 2 -> {
                            boolean inputFromUser = MainClass.inputBookingID();
                            if(inputFromUser){
                                Bookings.CHANGE_BOOKING = true;
                                TimetableLessons.viewTimetableLessons();
                                Bookings.CHANGE_BOOKING = false;
                            }
                            return;
                         }
                case 3 -> {
                            boolean inputFromUser = MainClass.inputBookingID();
                            if(inputFromUser){
                                Bookings.cancelBooking();
                                Bookings.TEMPORARY_BOOKING_ID = "";
                            }
                            return;
                         }
                case 4 -> {
                            boolean inputFromUser = MainClass.inputBookingID();
                            if(inputFromUser){
                                InstructorRatings.addRating();
                                Bookings.TEMPORARY_BOOKING_ID  = "";
                            }
                            return;
                         }
                case 5 -> Bookings.viewBookedLessons();
                case 6 ->{
                            return;
                        }
                default -> System.out.println("\nPlease Select valid Choice : ");
            }
        } while (selectedOption != 6);       
        return;
    }
    
}
