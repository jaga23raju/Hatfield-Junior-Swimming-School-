
package swimmingbookings;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class ReportsData implements GenerateReport{
    
       
    @Override
    public void generateReport() {
        int getMonthNumber = getMonthNumber();
        instructorRatingReport(getMonthNumber);
        learnerReport(getMonthNumber);
    }
    
    
    //get month number
    private static int getMonthNumber(){
        Scanner  sc = new Scanner(System.in);
        System.out.print("\nEnter Month Number to generate report (1 to 12) : ");
        String month = sc.nextLine();
        
        if(month.equalsIgnoreCase("") || !MainClass.checkDigit(month) || (Integer.parseInt(month) < 1 || 
                Integer.parseInt(month) > 12)){
            do{
                System.out.print("\nEnter Month Number to generate report (1 to 12) : ");
                month = sc.nextLine();
            }while(month.equalsIgnoreCase("") || !MainClass.checkDigit(month) || (Integer.parseInt(month) < 1
                    || Integer.parseInt(month) > 12));
        }
        return Integer.parseInt(month);
    }
    
    //instructorRatingReport
    public static void instructorRatingReport(int month){
        
        System.out.println("\nInstructor Report :");
        
        List<InstructorRatings> instructorRatings = InstructorRatings.getInstructorRatings();
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();
        List<Bookings> bookings = Bookings.getBookingData();
         
        HashMap<Integer, Integer> reviews = new HashMap<>();
        HashMap<Integer, Integer> records = new HashMap<>();
        HashMap<Integer, Double> calculate = new HashMap<>();
       
        System.out.println();
       
        for (InstructorRatings obj : instructorRatings){
            for (TimetableLessons timetableObj : timetableLessons){
                
                DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MMM-yyyy"); 
                String lessonMonth = "";
                try {
                    LocalDateTime parse = LocalDate.parse(timetableObj.getLesosnDate(), format).atStartOfDay();
                    lessonMonth = parse.format(DateTimeFormatter.ofPattern("M"));
                } catch (DateTimeParseException e) {
                    System.out.println("parsing datetime error : " + e.getMessage());
                }
                
                 //Lessons
                int timetableID = 0;
                for(Bookings bookingObj : bookings ){
                    if(bookingObj.getBookingID().equalsIgnoreCase(obj.getBookingID())){
                        timetableID = bookingObj.getTimetableID();
                        break;
                    }
                }
                    
                if(timetableObj.getTimetableID() == timetableID && lessonMonth.equalsIgnoreCase(String.valueOf(month))){
                    int instructor = timetableObj.getInstructorUserID();
                    int addStars = obj.getRatings();
                    
                    reviews.put(instructor, reviews.getOrDefault(instructor, 0) + addStars);
                    records.put(instructor, records.getOrDefault(instructor, 0) + 1);
                }
            }
        }

        for (Integer instructor : reviews.keySet()) {
            int calculateStars = reviews.get(instructor);
            int tot = records.get(instructor);

            if (tot > 0) {
                double avg = (double) calculateStars / tot;
                double ans = Math.round(avg * 10.0) / 10.0; 
                calculate.put(instructor, ans);
            }
        }
        if(!calculate.isEmpty()){
                                     
            System.out.println("\n---------------------------------------------------------------------------------------------------------");
            System.out.printf("|%-10s |%-20s | %-20s| %-10s | %-15s  | %-15s| \n", "CoachID","CoachName","PhoneNo","Age","Gender", "Average Rating");
            System.out.println("--------------------------------------------------------------------------------------------------------");
            for (Integer instructor : calculate.keySet()) {
                double avg = calculate.get(instructor);
                
                List<Users> users = Users.getUsersData();

                String instructorname = "";
                int age = 0;
                int id = 0;
                String phone = "";
                String gender = "";
                for(Users obj : users){
                   
                    if(obj.getUserID() == instructor){
                        instructorname = obj.getUsername();
                        id = obj.getUserID();
                        age = obj.getAge();
                        phone = obj.getContact();
                        gender = obj.getGender();
                        break;
                    }
                }
                System.out.printf("|%-10s |%-20s | %-20s| %-10s | %-15s  | %-15s| \n", id,
                        instructorname,phone,age,gender, avg);
            }
            System.out.println("--------------------------------------------------------------------------------------------------------");
        }else{
            System.out.println("No Data");
        }
        
    }
    
    
    //Learner Lessons Report
    public static void learnerReport(int month){
        System.out.println("\nLearner Report as below : ");
       
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();
        List<Bookings> bookings = Bookings.getBookingData();
         
        List<Users> users = Users.getUsersData();
       
        System.out.println();

        HashMap<Integer, int[]> learnerReport = new HashMap<>();
        Set<String> userID = new HashSet<>();             
        for(Bookings bookingObj : bookings){
            for(Users userObj : users){

                String monthNumber = "";
                for (TimetableLessons timetableObj : timetableLessons) {

                    if(timetableObj.getTimetableID() == bookingObj.getTimetableID()){
                        //Parse timetable classOn field
                       DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MMM-yyyy"); 

                        try {
                            LocalDateTime parsedDateTime = LocalDate.parse(timetableObj.getLesosnDate(), format).atStartOfDay();
                            monthNumber = parsedDateTime.format(DateTimeFormatter.ofPattern("M"));
                        } catch (DateTimeParseException e) {
                            System.out.println("parsing datetime error : " + e.getMessage());
                        }
                        break;
                    }
                }

                String keyData = String.valueOf(userObj.getUserID()) + bookingObj.getBookingID();

                if (!userID.contains(keyData)) {
                    userID.add(keyData);

                    if (userObj.getUserID() == bookingObj.getUserID() && 
                            monthNumber.equalsIgnoreCase(String.valueOf(month))) {

                        int userNum = userObj.getUserID();
                        int[] counter = learnerReport.getOrDefault(userNum, new int[3]);

                        if (bookingObj.getBookingStatus().equalsIgnoreCase(Bookings.BOOKED) 
                                || bookingObj.getBookingStatus().equalsIgnoreCase(Bookings.CHANGED)) {
                            counter[0]++;
                        }
                        if (bookingObj.getBookingStatus().equalsIgnoreCase(Bookings.CANCELLED)) {
                            counter[1]++;
                        }
                        if (bookingObj.getBookingStatus().equalsIgnoreCase(Bookings.ATTENDED)) {
                            counter[2]++;
                        }
                        learnerReport.put(userNum, counter);
                    }
                }
            }
        }
        
        if(!learnerReport.isEmpty()){
            int record =1;
            System.out.println("\n***********************************************************************************************************************************************************************");
            for (Map.Entry<Integer, int[]> entry : learnerReport.entrySet()) {
                int userNumber = entry.getKey();
                int[] counter = entry.getValue();

                //Learner details
                String name = "";
                String gender = "";
                String phone = "";
                int gradeLevel = 0;
                int age = 0;
                for(Users userObj : users){
                    if(userObj.getUserID() == userNumber){
                       name = userObj.getUsername();
                       gradeLevel = userObj.getGradeLevel();
                       age = userObj.getAge();
                       phone = userObj.getContact();
                       gender = userObj.getGender();
                       break;
                    }
                }
               
                System.out.println("\nLearner Record : "+record);
                System.out.println("\n--------------------------------------------");
                System.out.println("Name : "+name);
                System.out.println("Contact : "+phone);
                System.out.println("Gender : "+gender);
                System.out.println("Age : "+age+" yrs old");
                System.out.println("Current Grade  : "+gradeLevel);
                System.out.println("--------------------------------------------");

                
                System.out.println("Booked Lessons : "+counter[0]);
                System.out.println("Cancelled Lessons : "+counter[1]);
                System.out.println("Attended Lessons : "+counter[2]);
                System.out.println("--------------------------------");
                
                System.out.println("\nLessons Records : ");
                System.out.println("\n------------------------------------------------------------------------------------------------------------------------------------");
                System.out.printf("|%-15s| %-30s| %-12s| %-15s| %-15s| %-15s| %-15s|\n",
                        "TimetableID", "Name", "Slot", "LessonOn","Grade","Instructor","Status");
                System.out.println("------------------------------------------------------------------------------------------------------------------------------------");


                for(Bookings bookingObj : bookings){

                    if(bookingObj.getUserID() == userNumber){
                        //Class Detail
                        String title = "";
                        String timing = "";
                        String lessondate = "";
                        String instructor = "";
                        int classLevel = 0;
                        for (TimetableLessons timetableObj : timetableLessons) {
                            if(timetableObj.getTimetableID() == bookingObj.getTimetableID()){
                                title = timetableObj.getLesson();
                                timing = timetableObj.getSlot();
                                
                                for(Users userObj : users){
                                    if(userObj.getUserID() == timetableObj.getInstructorUserID()){
                                        instructor = userObj.getUsername();
                                        break;
                                    }
                                }
                                lessondate = timetableObj.getLesosnDate();
                                classLevel = timetableObj.getClassGradelevel();
                            }
                        }
                        System.out.printf("|%-15s| %-30s |%-12s| %-15s| %-15s| %-15s| %-15s|\n",
                        bookingObj.getTimetableID(), title, timing, lessondate,gradeLevel,
                        instructor,bookingObj.getBookingStatus());
                    }
                }               
                System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
                record++;
            }
            
            System.out.println("\n***********************************************************************************************************************************************************************");


        }else{
             System.out.println("No Data Found");
        }
    }
}
