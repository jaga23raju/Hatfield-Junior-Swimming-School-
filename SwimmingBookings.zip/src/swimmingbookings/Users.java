
package swimmingbookings;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;


public class Users {
    
    
    private int userID;
    private String username;
    private String contact;
    private int gradeLevel;
    private String gender;
    private int age;
    private String password;
    private String userType;
    
    public static int LOGGED_IN_ID = 0;
    
   public static List <Users> userDataData = new ArrayList<>();

    public Users(int userID, String username, String contact, int gradeLevel, String gender, int age, String password, String userType) {
        this.userID = userID;
        this.username = username;
        this.contact = contact;
        this.gradeLevel = gradeLevel;
        this.gender = gender;
        this.age = age;
        this.password = password;
        this.userType = userType;
    }

    public int getUserID() {
        return userID;
    }

    public String getUsername() {
        return username;
    }

    public String getContact() {
        return contact;
    }

    public int getGradeLevel() {
        return gradeLevel;
    }

    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public String getPassword() {
        return password;
    }

    public String getUserType() {
        return userType;
    }

    public static List<Users> getUsersData() {
        saveData();
        return userDataData;
    }

    public void setGradeLevel(int gradeLevel) {
        this.gradeLevel = gradeLevel;
    }
    
    private static void saveData(){
        Users user1 = new Users(101,"Kendy","01569 762287",1,"Female",5,"kendy@123","Learner");
        Users user2 = new Users(102,"Kelly","01492 868222",2,"Female",8,"kelly@123","Learner");
        Users user3 = new Users(103,"George","01204 361616",3,"Male",9,"George@123","Learner");
        Users user4 = new Users(104,"Thompson","01372 277200",4,"Male",11,"Thompson@123","Learner");
        Users user5 = new Users(105,"Jayden","01606 841000",5,"Male",4,"Jayden@123","Learner");
        Users user6 = new Users(106,"Colin","01578 722231",1,"Male",5,"Colin@123","Learner");
        Users user7 = new Users(107,"Danielle","01292 678193",2,"Male",9,"Danielle@123","Learner");
        Users user8 = new Users(108,"Anderson","01245 348597",3,"Male",8,"Anderson@123","Learner");
        Users user9 = new Users(109,"Keith","01382 642286",4,"Male",7,"Keith@123","Learner");
        Users user10 = new Users(110,"Richardson","01642 645255",5,"Male",9,"Richardson@123","Learner");
        Users user11 = new Users(111,"Hannah","01792 465676",1,"Female",8,"Hannah@123","Learner");
        Users user12 = new Users(112,"Bethany","020 8597 0229",2,"Male",6,"Bethany@123","Learner");
        Users user13 = new Users(113,"Harris","0191 274 3344",4,"Male",10,"Harris@123","Learner");
        Users user14 = new Users(114,"Olivia","01274 921318",3,"Male",11,"Olivia@123","Learner");
        Users user15 = new Users(115,"Adams","01455 890169",5,"Male",7,"Adams@123","Learner");
                
        Users user16 = new Users(116,"Holmes","01753 841791",5,"Male",35,"Holmes@123","Instructor");
        Users user17 = new Users(117,"Laura","0114 231 3285",5,"Female",45,"Laura@123","Instructor");
        Users user18 = new Users(118,"Jeremy","01737 789599",5,"Female",39,"Jeremy@123","Instructor");
        Users user19 = new Users(119,"Stevens","01234 711112",5,"Male",41,"Stevens@123","Instructor");
        Users user20 = new Users(120,"Nicole","01483 421911",5,"Female",40,"Nicole@123","Instructor");
        
        Users user21 = new Users(121,"Layla","0117 973 3020",5,"Female",42,"Layla@123","Reception");
        
        Users.userDataData.add(user1);
        Users.userDataData.add(user2);
        Users.userDataData.add(user3);
        Users.userDataData.add(user4);
        Users.userDataData.add(user5);
        Users.userDataData.add(user6);
        Users.userDataData.add(user7);
        Users.userDataData.add(user8);
        Users.userDataData.add(user9);
        Users.userDataData.add(user10);
        Users.userDataData.add(user11);
        Users.userDataData.add(user12);
        Users.userDataData.add(user13);
        Users.userDataData.add(user14);
        Users.userDataData.add(user15);
        
        Users.userDataData.add(user16);
        Users.userDataData.add(user17);
        Users.userDataData.add(user18);
        Users.userDataData.add(user19);
        Users.userDataData.add(user20);
        
        Users.userDataData.add(user21);
        
        
    }
   
   
    //View Users
    public static void viewUsers(){
        
        System.out.println("\n\n--------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-15s | %-25s | %-20s | %-18s | %-10s | %-10s |  %-15s | \n",
                "UserID","UserName", "GradeLevel","Contact","Age", "Gender","UserType");
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------");
        
        List<Users> userData = Users.getUsersData();
        Set<Integer> uniqueRows = new HashSet<>();
        
        for(Users obj : userData){
            if(!uniqueRows.contains(obj.getUserID()) && obj.getUserType().equalsIgnoreCase("Learner")){
                uniqueRows.add(obj.getUserID());

                System.out.printf("| %-15s | %-25s | %-20s | %-18s | %-10s | %-10s | %-15s |\n",
                 obj.getUserID(),obj.getUsername(), "Level : "+obj.getGradeLevel(),obj.getContact(),obj.getAge()+" yrs old", 
                 obj.getGender(), obj.getUserType());
            }
        }
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------");
    }
    
    //New Learner
    public static void addUser(){
        
        Scanner scanner = new Scanner(System.in);

        System.out.println("\nTo register with the swimming school, age should be 4 to 11 yrs. \n");
        
        System.out.print("\nPlease Enter User Name : ");
        String learnername = scanner.nextLine();
        
        if(learnername.equalsIgnoreCase("")){
            do{
                System.out.print("\nPlease Enter User Name : ");
                learnername = scanner.nextLine();
            }while(learnername.equalsIgnoreCase(""));
        }
       
        System.out.print("\nPlease Enter Password : ");
        String password = scanner.nextLine();
        
        if(password.equalsIgnoreCase("")){
            do{
                System.out.print("\nPlease Enter Password : ");
                password = scanner.nextLine();
            }while(password.equalsIgnoreCase(""));
        }
        
        System.out.print("\nPlease Enter your Age ( 4 to 11 ) : ");
        String age = scanner.nextLine();
         
        if(age.equalsIgnoreCase("") || !MainClass.checkDigit(age) || Integer.parseInt(age) < 4 || Integer.parseInt(age) > 11){
            do{
                System.out.print("\nPlease Enter your Age ( 4 to 11 ) : ");
                age = scanner.nextLine();
            }while(age.equalsIgnoreCase("") || !MainClass.checkDigit(age) || Integer.parseInt(age) < 4 || Integer.parseInt(age) > 11);
        }
    

        System.out.print("\nPlease Enter Current Grade Level between 1 to 5 : ");
        String currentGrade = scanner.nextLine();
        
         
        if(currentGrade.equalsIgnoreCase("") || !MainClass.checkDigit(currentGrade) || (Integer.parseInt(currentGrade) < 1 || Integer.parseInt(currentGrade) > 5)){
            do{
                System.out.print("\nPlease Enter Current Grade Level between 1 to 5 : ");
                currentGrade = scanner.nextLine();
            }while(currentGrade.equalsIgnoreCase("") || !MainClass.checkDigit(currentGrade) || (Integer.parseInt(currentGrade) < 1 || Integer.parseInt(currentGrade) > 5));
        }
        
        
        System.out.print("\nPlease Enter Contact : ");
        String contact = scanner.nextLine();
        
        if(contact.equalsIgnoreCase("")){
            do{
                System.out.print("\nPlease Enter Contact : ");
                contact = scanner.nextLine();
            }while(contact.equalsIgnoreCase(""));
        }
        
        System.out.print("\nPlease Enter Gender (Male | Female) : ");
        String learnergender = scanner.nextLine();
        
        if(learnergender.equalsIgnoreCase("") || (!learnergender.equalsIgnoreCase("M") 
                && !learnergender.equalsIgnoreCase("F") && !learnergender.equalsIgnoreCase("Female") && 
                !learnergender.equalsIgnoreCase("Male"))){
            do{
                System.out.print("\nPlease Enter Gender (Male | Female) : ");
                learnergender = scanner.nextLine();
            }while(learnergender.equalsIgnoreCase("") || (!learnergender.equalsIgnoreCase("M")
                    && !learnergender.equalsIgnoreCase("F") && !learnergender.equalsIgnoreCase("Female") && 
                !learnergender.equalsIgnoreCase("Male")));
        }
      
        //Get user id 
        List<Users> userData = Users.getUsersData();
        int lastuserID = 0;
        for(Users obj : userData){
           lastuserID = obj.getUserID();
        }
  
        //Add Learner
        Users userObj = new Users((lastuserID+1),learnername,contact,Integer.parseInt(currentGrade),learnergender,Integer.parseInt(age),
                password,"Learner");
        Users.userDataData.add(userObj);
        System.out.println("\nSuccess Msg - Thanks for getting register. Your User ID : "+(lastuserID+1));
    }
    
    
    //password Found
    public static boolean passwordFound(String password, int userID){
        boolean found = false;
        
        List<Users> userData = Users.getUsersData();
        
        for(Users obj : userData){
            if(obj.getPassword().equalsIgnoreCase(password) && obj.getUserID() == userID){
                found = true;
                break;
            }
        }
        return found;
    }
    
    
    //check learner found
    public static boolean isUserFound(int userID){
        boolean found = false;
        
        List<Users> userData = Users.getUsersData();
        
        for(Users obj : userData){
            if(obj.getUserID() == userID){
                found = true;
                break;
            }
        }
        return found;
    }
    
    
    //check learner found
    public static boolean isInstructorFound(int userID){
        boolean found = false;
        
        List<Users> userData = Users.getUsersData();
        
        for(Users obj : userData){
            if(obj.getUserID() == userID && obj.getUserType().equalsIgnoreCase("Instructor")){
                found = true;
                break;
            }
        }
        return found;
    }
    
    
    //get logged user roleType
    public static String getUserRoleOfLoggedInUser(int userID){
        String roleType = "";
        
        List<Users> userData = Users.getUsersData();
        
        for(Users obj : userData){
            if(obj.getUserID() == userID){
                roleType = obj.getUserType();
                break;
            }
        }
        return roleType;
    }
    
    //increaseLearnerGradeLevel
    public static void increaseLearnerGradeLevel(){
        int LOGGED_IN_ID = Users.LOGGED_IN_ID; 
        List<Users> users = Users.getUsersData();
        int userGrade = 0;
        for(Users obj : users){
            if(obj.getUserID() == LOGGED_IN_ID){
                userGrade = obj.getGradeLevel();
                obj.setGradeLevel(userGrade +1);
                break;
            }
        }
    }
    
    
    
}
