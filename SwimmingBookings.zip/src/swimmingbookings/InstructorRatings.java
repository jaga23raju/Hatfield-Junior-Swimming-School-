
package swimmingbookings;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;


public class InstructorRatings {
    
    
    private String bookingID;
    private int ratings;
    private String review;
    private int givenTo;
    private String givenOn;
    
    public static List <InstructorRatings> instructorRatings = new ArrayList<>();

    public InstructorRatings(String bookingID, int ratings, String review, int givenTo, String givenOn) {
        this.bookingID = bookingID;
        this.ratings = ratings;
        this.review = review;
        this.givenTo = givenTo;
        this.givenOn = givenOn;
    }

    public String getBookingID() {
        return bookingID;
    }

    public int getRatings() {
        return ratings;
    }

    public String getReview() {
        return review;
    }

    public int getGivenTo() {
        return givenTo;
    }

    public String getGivenOn() {
        return givenOn;
    }

    public static List<InstructorRatings> getInstructorRatings() {
        return instructorRatings;
    }
    
    
    //addRating
    public static void addRating(){
        Scanner scanner = new Scanner(System.in);
        
        LocalDateTime currentDateTime = LocalDateTime.now();
        
        //Already Atteded
        boolean isAttended = Bookings.isBookingAlreadyAttendedByLearner(Bookings.TEMPORARY_BOOKING_ID );
        if(isAttended){
            System.out.println("\nBooking Already Attended");
            return;
        }
        
        //Already cancelled
        boolean isCancelled = Bookings.isBookingAlreadyCancelByLearner(Bookings.TEMPORARY_BOOKING_ID );
        if(isCancelled){
            System.out.println("\nBooking Already Cancelled");
            return;
        }
        
        List<Bookings> bookings = Bookings.getBookingData();

        //Brief reviewForInstructorription
        System.out.print("\nPlease Enter Your Review for instructor and his instructed lesson : ");
        String reviewForInstructor = scanner.nextLine();
        
        if(reviewForInstructor.equalsIgnoreCase("")){
            do{
                System.out.print("\nPlease Enter Your Review for instructor and his instructed lesson : ");
                reviewForInstructor = scanner.nextLine();
            }while(reviewForInstructor.equalsIgnoreCase(""));
        }     
        

        //Rating
        System.out.println("\n1 for Very dissatisfied");
        System.out.println("2 for Dissatisfied");
        System.out.println("3 for Ok");
        System.out.println("4 for Satisfied");
        System.out.println("5 for Very Satisfied");
        System.out.print("\nPlease Enter Rating Value displayed above to attend class : ");
        String rating = scanner.nextLine();
        
        if(rating.equalsIgnoreCase("") || !MainClass.checkDigit(rating) || Integer.parseInt(rating) < 1 || 
                Integer.parseInt(rating) > 5){
            do{
                System.out.print("\nPlease Enter Valid Rating (1 to 5) : ");
                rating = scanner.nextLine();
            }while(rating.equalsIgnoreCase("") || !MainClass.checkDigit(rating) || Integer.parseInt(rating) < 1 ||
                    Integer.parseInt(rating) > 5);
        }     
        
        int instructorID = Bookings.returnBookingInstructorID();
        //Add Rating
        InstructorRatings ratingobj = new InstructorRatings(Bookings.TEMPORARY_BOOKING_ID ,Integer.parseInt(rating),reviewForInstructor, 
                instructorID,String.valueOf(currentDateTime));
        InstructorRatings.instructorRatings.add(ratingobj);
        
        //Updae status
        int timetableID = 0;
        for(Bookings obj : bookings){
            if(obj.getBookingID().equalsIgnoreCase(Bookings.TEMPORARY_BOOKING_ID )){
                timetableID = obj.getTimetableID();
                obj.setBookingStatus(Bookings.ATTENDED);
                break;
            }
        }
        
        //Update current grade level
        int lessonGrade = 0;
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();
        for(TimetableLessons obj : timetableLessons){
            if(obj.getTimetableID() == timetableID){
                lessonGrade = obj.getClassGradelevel();
                break;
            }
        }
        int LOGGED_IN_ID = Users.LOGGED_IN_ID; 
        List<Users> users = Users.getUsersData();
        int userGrade = 0;
        for(Users obj : users){
            if(obj.getUserID() == LOGGED_IN_ID){
                userGrade = obj.getGradeLevel();
                break;
            }
        }
        
        System.out.println("\nBooking Attended");
        if(lessonGrade > userGrade){
            Users.increaseLearnerGradeLevel();
            System.out.println("\nCurrent Grade Level is updated by attending higher grade level lesson.");
        }

        //increaseLessonSeatsAvailability
        TimetableLessons.increaseLessonSeatsAvailability(timetableID);
        
    }
    
    
    
      
    //givenRatings
    public static void givenRatings(){
          
        System.out.println("\n\n-----------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-10s | %-10s | %-12s | %-15s | %-22s | %-13s | %-10s |  %-30s | \n",
                "BookingID","TimetableID","Lesson", "InstructedBy","BookedBy","Status","Ratings","Review");
        System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
        
        List<Bookings> bookings = Bookings.getBookingData();
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();
        List<InstructorRatings> instructorRatings = InstructorRatings.getInstructorRatings();
        List<Users> users = Users.getUsersData();
        
        //Get logged user role
        String role = "";
         for(Users userObj : users ){
            if(userObj.getUserID() == Users.LOGGED_IN_ID){
                role = userObj.getUserType();
                break;
            }
        }
        
        Set<String> uniqueRows = new HashSet<>(); 
        
        for(InstructorRatings robj : instructorRatings){
            for(Bookings obj : bookings){
                if(robj.getBookingID().equalsIgnoreCase(obj.getBookingID())){
                    
                    if(!uniqueRows.contains(robj.getBookingID())){

                        //Lessons
                        String lessonName = "";
                        for(TimetableLessons timetableLessonsObj : timetableLessons ){
                            if(timetableLessonsObj.getTimetableID() == obj.getTimetableID()){
                                lessonName = timetableLessonsObj.getLesson();
                                break;
                            }
                        }
                        //Learner
                        String bookedBy = "";
                        for(Users userObj : users ){
                            if(userObj.getUserID() == obj.getUserID()){
                                bookedBy = userObj.getUsername();
                                break;
                            }
                        }
                        //Coach
                        String instructor = "";
                        for(Users userObj : users ){
                            if(userObj.getUserID() == obj.getInstructedBy()){
                                instructor = userObj.getUsername();
                                break;
                            }
                        }
                        uniqueRows.add(obj.getBookingID());

                        if(role.equalsIgnoreCase("learner")){
                            if(obj.getUserID() == Users.LOGGED_IN_ID){
                               System.out.printf("| %-10s | %-10s | %-12s | %-15s | %-22s | %-13s | %-10s |  %-30s | \n",
                        obj.getBookingID(),obj.getTimetableID(),lessonName, instructor,bookedBy,obj.getBookingStatus(),
                        robj.getRatings(),robj.getReview());
                            }
                        }else{
                            System.out.printf("| %-10s | %-10s | %-12s | %-15s | %-22s | %-13s | %-10s |  %-30s | \n",
                        obj.getBookingID(),obj.getTimetableID(),lessonName, instructor,bookedBy,obj.getBookingStatus(),
                        robj.getRatings(),robj.getReview());
                        }
                    }
                }
            }
        }
        
        System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
        
    }
    
    
 
    
}
