
package swimmingbookings;

import java.util.List;
import java.util.Scanner;


public class MainClass {
    
    
    public static void main(String[] args) {
        
        System.out.println("\nX--------------------------------------------------------------------------------------------X");
        System.out.println("\tUse our online system to manage your classes : ");
        System.out.println("X--------------------------------------------------------------------------------------------X");
               
        int selectedOption;
        do {
            selectedOption = MenuClass.mainMenuOptions();
            switch (selectedOption) {
                case 1 -> Bookings.continueBooking();
                case 2 ->{
                            System.out.println("\nX-------------------------------------X");
                            System.out.println("\tThanks for using panel");
                            System.out.println("X-------------------------------------X");
                            System.exit(0);
                        }
                default -> System.out.println("\nPlease Select Valid Choice ");
            }
        } while (selectedOption != 2);
    }
     
    //check digit
    public static boolean checkDigit(String stringdata)
    {
        if (stringdata == null || stringdata.isEmpty()) {
             return false;
         }
         for (int i = 0; i < stringdata.length(); i++) {
             if (!Character.isDigit(stringdata.charAt(i))) {
                 return false;
             }
         }
         return true;
    }
    
         
    //inputLessonIDForBooking
    public static void inputLessonIDForBooking(){
        Scanner scanner = new Scanner(System.in);
        
        //Lesson name
        System.out.print("\nPlease Enter Timetable ID to book a lesson : ");
        String timetableID = scanner.nextLine();
        
        if(timetableID.equalsIgnoreCase("") || !MainClass.checkDigit(timetableID)){
            do{
                System.out.print("\nPlease Enter Valid Timetable ID : ");
                timetableID = scanner.nextLine();
            }while(timetableID.equalsIgnoreCase("") || !MainClass.checkDigit(timetableID));
        }        
        
        //Is lesson exists
        boolean found = TimetableLessons.isLessonFound(Integer.parseInt(timetableID));
        
        if(!found){
            System.out.print("\nTimetable ID was not found. ");
            return;
        }
       
        //Duplicate Booking
        boolean isBookingTwiceByLearner = Bookings.isBookingTwiceByLearner(Integer.parseInt(timetableID));
        if(isBookingTwiceByLearner){
            System.out.println("\nTwice Booking");
            return;
        }
        
        //Allowed Grade
        boolean validLessonToBook = TimetableLessons.validLessonToBook(Integer.parseInt(timetableID));
        if(!validLessonToBook){
            System.out.println("\nSelected Lesson is not of your current grade level and not one level higher than your current grade level");
            return;
        }
        
        int seats = TimetableLessons.getAvailableSeats(Integer.parseInt(timetableID));
        if(seats == 0){
            System.out.println("\nNo Seat Available");
            return;
        }
         
        //Book
        Bookings.scheduleBooking(Integer.parseInt(timetableID));
        
        System.out.println("\nSuccess : Booking Confirmed");
    }
    
    
     
    
    //takeBookingID
    public static boolean inputBookingID(){
        boolean inputFromUser = false;
        
        Scanner scanner = new Scanner(System.in);
        
        //Lesson name
        System.out.print("\nPlease Enter Booking ID : ");
        String bookingID = scanner.nextLine();
        
        if(bookingID.equalsIgnoreCase("")){
            do{
                System.out.print("\nPlease Enter Booking ID : ");
                bookingID = scanner.nextLine();
            }while(bookingID.equalsIgnoreCase(""));
        }        
        
        //Is lesson exists
        boolean found = Bookings.isBookingIDFound(bookingID);
        
        if(!found){
            System.out.print("\nBooking ID was not found. ");
            return inputFromUser;
        }
        
 
        Bookings.TEMPORARY_BOOKING_ID = bookingID;
        inputFromUser = true;
        return inputFromUser;
    }
    
    
    
    //Take Booking Lesson name to chage
    public static void inputLessonIDToUpdateBooking(){
        Scanner scanner = new Scanner(System.in);
        
                
        //Already Atteded
        boolean isBookingAlreadyAttendedByLearner = Bookings.isBookingAlreadyAttendedByLearner( Bookings.TEMPORARY_BOOKING_ID );
        if(isBookingAlreadyAttendedByLearner){
            System.out.println("\nAlready Attended Lesson");
            return;
        }
        
        //Already cancelled
        boolean isBookingAlreadyCancelByLearner = Bookings.isBookingAlreadyCancelByLearner( Bookings.TEMPORARY_BOOKING_ID );
        if(isBookingAlreadyCancelByLearner){
            System.out.println("\nAlready Cancelled Lesson");
            return;
        }
        
        //Lesson name
        System.out.print("\nPlease Enter Timetable ID to change a booking : ");
        String timetableID = scanner.nextLine();
        
        if(timetableID.equalsIgnoreCase("")){
            do{
                System.out.print("\nPlease Enter Timetable ID to change a booking : ");
                timetableID = scanner.nextLine();
            }while(timetableID.equalsIgnoreCase(""));
        }        
        
        //Is lesson exists
        boolean found = TimetableLessons.isLessonFound(Integer.parseInt(timetableID));
        
        if(!found){
            System.out.print("\nTimetable ID was not found ");
            return;
        }
        
         //get lesson id
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();
        
        int seats = 0;
        for(TimetableLessons obj : timetableLessons){
            if(obj.getTimetableID() == Integer.parseInt(timetableID)){
                seats = obj.getMaxSeatsForLesson();
                break;
            }
        }
        
        //Twice Booking
        boolean isBookingTwiceByLearner = Bookings.isBookingTwiceByLearner(Integer.parseInt(timetableID));
        if(isBookingTwiceByLearner){
            System.out.println("\nTwice Booking");
            return;
        }
        
         
        //Allowed Grade
        boolean validLessonToBook = TimetableLessons.validLessonToBook(Integer.parseInt(timetableID));
        if(!validLessonToBook){
            System.out.println("\nSelected Lesson is not of your current grade level and not one level higher than your current grade level");
            return;
        }
        
        if(seats == 0){
            System.out.println("\nNo Seat Available");
            return;
        }
        
        //Change
        Bookings.updateBooking(Integer.parseInt(timetableID));
        
        Bookings.TEMPORARY_BOOKING_ID = "";
        System.out.println("\nSuccess : Lesson Updated");
    }
    

    
    
    
}
