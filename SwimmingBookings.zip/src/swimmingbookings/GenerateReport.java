
package swimmingbookings;


public interface GenerateReport {
    
    void generateReport();
}
