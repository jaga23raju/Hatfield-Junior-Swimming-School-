
package swimmingbookings;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;


public class TimetableLessons {
    
    
    private int timetableID;
    private String lesson;
    private String day;
    private String slot;
    private String lesosnDate;
    private int classGradelevel;
    private int instructorUserID;
    private int maxSeatsForLesson;
    
    public static int TIMETABLE_FILTER_BY_GRADE_LEVEL = 0;
    public static int TIMETABLE_FILTER_BY_INSTRUCTOR = 0;
    public static int MAX_SEATS_ALLOWED = 4;
    public static String TIMETABLE_FILTER_BY_DAY = "";

    public static List <TimetableLessons> timetableLessons = new ArrayList<>();

    public TimetableLessons(int timetableID, String lesson, String day, String slot, String lesosnDate, int classGradelevel, int instructorUserID, int maxSeatsForLesson) {
        this.timetableID = timetableID;
        this.lesson = lesson;
        this.day = day;
        this.slot = slot;
        this.lesosnDate = lesosnDate;
        this.classGradelevel = classGradelevel;
        this.instructorUserID = instructorUserID;
        this.maxSeatsForLesson = maxSeatsForLesson;
    }

    public int getTimetableID() {
        return timetableID;
    }

    public String getLesson() {
        return lesson;
    }

    public String getDay() {
        return day;
    }

    public String getSlot() {
        return slot;
    }

    public String getLesosnDate() {
        return lesosnDate;
    }

    public int getClassGradelevel() {
        return classGradelevel;
    }

    public int getInstructorUserID() {
        return instructorUserID;
    }

    public int getMaxSeatsForLesson() {
        return maxSeatsForLesson;
    }

    public void setMaxSeatsForLesson(int maxSeatsForLesson) {
        this.maxSeatsForLesson = maxSeatsForLesson;
    }

    public static List<TimetableLessons> getTimetableLessons() {
        saveData();
        return timetableLessons;
    }
    
    
    private static void saveData(){
        TimetableLessons les1 = new TimetableLessons(101,"Front Crawl","Monday","4-5pm","01-Apr-2024",1,
                116,MAX_SEATS_ALLOWED);
    
        TimetableLessons les2 = new TimetableLessons(102,"Crawling","Monday","5-6pm","01-Apr-2024",2,
                117,MAX_SEATS_ALLOWED);
    
        TimetableLessons les3 = new TimetableLessons(103,"Breaststroke","Monday","6-7pm","01-Apr-2024",3,
                118,MAX_SEATS_ALLOWED);
        
        TimetableLessons les4 = new TimetableLessons(104,"Front Crawl","Wednesday","4-5pm","03-Apr-2024",1,
                119,MAX_SEATS_ALLOWED);
    
        TimetableLessons les5 = new TimetableLessons(105,"Crawling","Wednesday","5-6pm","03-Apr-2024",2,
                120,MAX_SEATS_ALLOWED);
    
        TimetableLessons les6 = new TimetableLessons(106,"Breaststroke","Wednesday","6-7pm","03-Apr-2024",3,
                118,MAX_SEATS_ALLOWED);
    
        TimetableLessons les7 = new TimetableLessons(107,"Front Crawl","Friday","4-5pm","05-Apr-2024",4,
                116,MAX_SEATS_ALLOWED);
    
        TimetableLessons les8 = new TimetableLessons(108,"Crawling","Friday","5-6pm","05-Apr-2024",5,
                117,MAX_SEATS_ALLOWED);
    
        TimetableLessons les9 = new TimetableLessons(109,"Breaststroke","Friday","6-7pm","05-Apr-2024",3,
                118,MAX_SEATS_ALLOWED);
    
        
        TimetableLessons les10 = new TimetableLessons(110,"Crawling","Saturday","2-3pm","06-Apr-2024",4,
                119,MAX_SEATS_ALLOWED);
    
        TimetableLessons les11 = new TimetableLessons(111,"Breaststroke","Saturday","3-4pm","06-Apr-2024",3,
                120,MAX_SEATS_ALLOWED);
    
        
        TimetableLessons les12 = new TimetableLessons(112,"Front Crawl","Monday","4-5pm","08-Apr-2024",1,
                116,MAX_SEATS_ALLOWED);
    
        TimetableLessons les13 = new TimetableLessons(113,"Crawling","Monday","5-6pm","08-Apr-2024",2,
                117,MAX_SEATS_ALLOWED);
    
        TimetableLessons les14 = new TimetableLessons(114,"Breaststroke","Monday","6-7pm","08-Apr-2024",5,
                118,MAX_SEATS_ALLOWED);
        
        TimetableLessons les15 = new TimetableLessons(115,"Front Crawl","Wednesday","4-5pm","10-Apr-2024",1,
                116,MAX_SEATS_ALLOWED);
    
        TimetableLessons les16 = new TimetableLessons(116,"Crawling","Wednesday","5-6pm","10-Apr-2024",2,
                117,MAX_SEATS_ALLOWED);
    
        TimetableLessons les17 = new TimetableLessons(117,"Breaststroke","Wednesday","6-7pm","10-Apr-2024",3,
                119,MAX_SEATS_ALLOWED);
    
        TimetableLessons les18 = new TimetableLessons(118,"Front Crawl","Friday","4-5pm","12-Apr-2024",1,
                120,MAX_SEATS_ALLOWED);
    
        TimetableLessons les19 = new TimetableLessons(119,"Crawling","Friday","5-6pm","12-Apr-2024",4,
                117,MAX_SEATS_ALLOWED);
    
        TimetableLessons les20 = new TimetableLessons(120,"Breaststroke","Friday","6-7pm","12-Apr-2024",3,
                118,MAX_SEATS_ALLOWED);
    
        
        TimetableLessons les21 = new TimetableLessons(121,"Crawling","Saturday","2-3pm","13-Apr-2024",2,
                117,MAX_SEATS_ALLOWED);
    
        TimetableLessons les22 = new TimetableLessons(122,"Breaststroke","Saturday","3-4pm","13-Apr-2024",3,
                119,MAX_SEATS_ALLOWED);
    
        
        TimetableLessons les23 = new TimetableLessons(123,"Front Crawl","Monday","4-5pm","15-Apr-2024",1,
                116,MAX_SEATS_ALLOWED);
    
        TimetableLessons les24 = new TimetableLessons(124,"Crawling","Monday","5-6pm","15-Apr-2024",4,
                117,MAX_SEATS_ALLOWED);
    
        TimetableLessons les25 = new TimetableLessons(125,"Breaststroke","Monday","6-7pm","15-Apr-2024",3,
                118,MAX_SEATS_ALLOWED);
        
        TimetableLessons les26 = new TimetableLessons(126,"Front Crawl","Wednesday","4-5pm","17-Apr-2024",5,
                120,MAX_SEATS_ALLOWED);
    
        TimetableLessons les27 = new TimetableLessons(127,"Crawling","Wednesday","5-6pm","17-Apr-2024",2,
                117,MAX_SEATS_ALLOWED);
    
        TimetableLessons les28 = new TimetableLessons(128,"Breaststroke","Wednesday","6-7pm","17-Apr-2024",3,
                118,MAX_SEATS_ALLOWED);
    
        TimetableLessons les29 = new TimetableLessons(129,"Front Crawl","Friday","4-5pm","19-Apr-2024",5,
                119,MAX_SEATS_ALLOWED);
    
        TimetableLessons les30 = new TimetableLessons(130,"Crawling","Friday","5-6pm","19-Apr-2024",2,
                120,MAX_SEATS_ALLOWED);
    
        TimetableLessons les31 = new TimetableLessons(131,"Breaststroke","Friday","6-7pm","19-Apr-2024",3,
                118,MAX_SEATS_ALLOWED);
    
        
        TimetableLessons les32 = new TimetableLessons(132,"Crawling","Saturday","2-3pm","20-Apr-2024",2,
                117,MAX_SEATS_ALLOWED);
    
        TimetableLessons les33 = new TimetableLessons(133,"Breaststroke","Saturday","3-4pm","20-Apr-2024",1,
                118,MAX_SEATS_ALLOWED);
    
        
        TimetableLessons les34 = new TimetableLessons(134,"Front Crawl","Monday","4-5pm","21-Apr-2024",1,
                116,MAX_SEATS_ALLOWED);
    
        TimetableLessons les35 = new TimetableLessons(135,"Crawling","Monday","5-6pm","21-Apr-2024",2,
                119,MAX_SEATS_ALLOWED);
    
        TimetableLessons les36 = new TimetableLessons(136,"Breaststroke","Monday","6-7pm","21-Apr-2024",3,
                118,MAX_SEATS_ALLOWED);
        
        TimetableLessons les37 = new TimetableLessons(137,"Front Crawl","Wednesday","4-5pm","23-Apr-2024",4,
                120,MAX_SEATS_ALLOWED);
    
        TimetableLessons les38 = new TimetableLessons(138,"Crawling","Wednesday","5-6pm","23-Apr-2024",2,
                117,MAX_SEATS_ALLOWED);
    
        TimetableLessons les39 = new TimetableLessons(139,"Breaststroke","Wednesday","6-7pm","23-Apr-2024",3,
                118,MAX_SEATS_ALLOWED);
    
        TimetableLessons les40 = new TimetableLessons(140,"Front Crawl","Friday","4-5pm","25-Apr-2024",1,
                119,MAX_SEATS_ALLOWED);
    
        TimetableLessons les41 = new TimetableLessons(141,"Crawling","Friday","5-6pm","25-Apr-2024",5,
                120,MAX_SEATS_ALLOWED);
    
        TimetableLessons les42 = new TimetableLessons(142,"Breaststroke","Friday","6-7pm","25-Apr-2024",3,
                118,MAX_SEATS_ALLOWED);
    
        
        TimetableLessons les43 = new TimetableLessons(143,"Crawling","Saturday","2-3pm","26-Apr-2024",1,
                119,MAX_SEATS_ALLOWED);
    
        TimetableLessons les44 = new TimetableLessons(144,"Breaststroke","Saturday","3-4pm","26-Apr-2024",3,
                120,MAX_SEATS_ALLOWED);
    
        
        TimetableLessons.timetableLessons.add(les1);
        TimetableLessons.timetableLessons.add(les2);
        TimetableLessons.timetableLessons.add(les3);
        TimetableLessons.timetableLessons.add(les4);
        TimetableLessons.timetableLessons.add(les5);
        TimetableLessons.timetableLessons.add(les6);
        TimetableLessons.timetableLessons.add(les7);
        TimetableLessons.timetableLessons.add(les8);
        TimetableLessons.timetableLessons.add(les9);
        TimetableLessons.timetableLessons.add(les10);
        TimetableLessons.timetableLessons.add(les11);
        TimetableLessons.timetableLessons.add(les12);
        TimetableLessons.timetableLessons.add(les13);
        TimetableLessons.timetableLessons.add(les14);
        TimetableLessons.timetableLessons.add(les15);
        TimetableLessons.timetableLessons.add(les16);
        TimetableLessons.timetableLessons.add(les17);
        TimetableLessons.timetableLessons.add(les18);
        TimetableLessons.timetableLessons.add(les19);
        TimetableLessons.timetableLessons.add(les20);
        TimetableLessons.timetableLessons.add(les21);
        TimetableLessons.timetableLessons.add(les22);
        TimetableLessons.timetableLessons.add(les23);
        TimetableLessons.timetableLessons.add(les24);
        TimetableLessons.timetableLessons.add(les25);
        TimetableLessons.timetableLessons.add(les26);
        TimetableLessons.timetableLessons.add(les27);
        TimetableLessons.timetableLessons.add(les28);
        TimetableLessons.timetableLessons.add(les29);
        TimetableLessons.timetableLessons.add(les30);
        TimetableLessons.timetableLessons.add(les31);
        TimetableLessons.timetableLessons.add(les32);
        TimetableLessons.timetableLessons.add(les33);
        TimetableLessons.timetableLessons.add(les34);
        TimetableLessons.timetableLessons.add(les35);
        TimetableLessons.timetableLessons.add(les36);
        TimetableLessons.timetableLessons.add(les37);
        TimetableLessons.timetableLessons.add(les38);
        TimetableLessons.timetableLessons.add(les39);
        TimetableLessons.timetableLessons.add(les40);
        TimetableLessons.timetableLessons.add(les41);
        TimetableLessons.timetableLessons.add(les42);
        TimetableLessons.timetableLessons.add(les43);
        TimetableLessons.timetableLessons.add(les44);
        
    }
    

    
    //View Timetable Lessons
    public static void viewTimetableLessons(){
        
        System.out.println("\n\n----------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-10s | %-12s | %-15s | %-10s | %-10s | %-20s |  %-18s |  %-15s | \n",
                "Lesson ID","Name", "Grade Level","Day","Time", "Coach","Allowed Learners","Date");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
        
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();
        List<Users> userData = Users.getUsersData();
        Set<Integer> uniqueRows = new HashSet<>(); 
        
        for(TimetableLessons obj : timetableLessons){
            if(!uniqueRows.contains(obj.getTimetableID())){
                uniqueRows.add(obj.getTimetableID());
                
                String instructor = "";
                for(Users userdataObj : userData){
                    if(userdataObj.getUserID() == obj.getInstructorUserID()){
                        instructor = userdataObj.getUsername();
                        break;
                    }
                }
                System.out.printf("| %-10s | %-12s | %-15s | %-10s | %-10s | %-20s |  %-18s |  %-15s | \n",
                   obj.getTimetableID(),obj.getLesson(), "Level : "+obj.getClassGradelevel(),obj.getDay(),
                   obj.getSlot(), instructor,obj.getMaxSeatsForLesson(),obj.getLesosnDate());
            }
        }
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
        
        MenuClass.applyFilterOnTimetableLesson();
    }
    
    
    //Instructor Timetable Lessons
    public static void inputInstructorIdToApplyFilter(){
        Scanner scanner = new Scanner(System.in);
        
        List<Users> userData = Users.getUsersData();
        
        System.out.println("\n\n--------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-15s | %-25s | %-20s | %-18s | %-10s | %-10s |  %-15s | \n",
                "InstructorID","UserName", "GradeLevel","Contact","Age", "Gender","UserType");
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------");
        Set<Integer> uniqueRows = new HashSet<>(); 

        for(Users obj : userData){
            if(obj.getUserType().equalsIgnoreCase("Instructor") && !uniqueRows.contains(obj.getUserID())){
                uniqueRows.add(obj.getUserID());
                  System.out.printf("| %-15s | %-25s | %-20s | %-18s | %-10s | %-10s | %-15s |\n",
                 obj.getUserID(),obj.getUsername(), "Level : "+obj.getGradeLevel(),obj.getContact(),obj.getAge()+" yrs old", 
                 obj.getGender(), obj.getUserType());
            }
        }
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------");

        //InstructorID
        System.out.print("\nPlease Enter InstructorID to apply filter on timetable lessons : ");
        String instructorID = scanner.nextLine();
        
        if(instructorID.equalsIgnoreCase("") || !MainClass.checkDigit(instructorID)){
            do{
                System.out.print("\nPlease Enter Valid InstructorID to apply filter on timetable lessons :  ");
                instructorID = scanner.nextLine();
            }while(instructorID.equalsIgnoreCase("") || !MainClass.checkDigit(instructorID));
        }
          
        boolean foundInstructor = Users.isInstructorFound(Integer.parseInt(instructorID));
        
        if(!foundInstructor){
            System.out.print("\nInstructor ID was not found ");
            return;
        }
        
        TIMETABLE_FILTER_BY_INSTRUCTOR = Integer.parseInt(instructorID);
        filteredTimetableLessons();
    }
    
    
    //Day Timetable Lessons
    public static void inputDayToApplyFilter(){
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("---------------");
        System.out.println("1 for Monday");
        System.out.println("2 for Wednesday");
        System.out.println("3 for Friday");
        System.out.println("4 for Saturday");
        System.out.println("---------------");
        
        //Day
        System.out.print("\nPlease Enter Day from above days to filter timetable : ");
        String day = scanner.nextLine();
        
          
        if(day.equalsIgnoreCase("") || !(day.equalsIgnoreCase("1") || day.equalsIgnoreCase("2") ||
                day.equalsIgnoreCase("3") || day.equalsIgnoreCase("4"))){
            do{
                System.out.print("\nPlease Enter Valid Day : ");
                day = scanner.nextLine();
            }while(day.equalsIgnoreCase("") || !(day.equalsIgnoreCase("1") || day.equalsIgnoreCase("2") ||
                day.equalsIgnoreCase("3") || day.equalsIgnoreCase("4")));
        }        
        
        if(day.equalsIgnoreCase("1")){
            day = "Monday";
        }else if(day.equalsIgnoreCase("2")){
            day = "Wednesday";
        }else if(day.equalsIgnoreCase("3")){
            day = "Friday";
        }else if(day.equalsIgnoreCase("4")){
            day = "Saturday";
        }
    
        
        TIMETABLE_FILTER_BY_DAY = day;
        filteredTimetableLessons();
    }
    
    
    //Grade Level Timetable Lessons
    public static void inputGradeLevelToApplyFilter(){
        Scanner scanner = new Scanner(System.in);
        
        //Grade Level
        System.out.print("\nPlease Enter Grade Level to apply filter on timetable lessons : ");
        String gradeLevel = scanner.nextLine();
        
        if(gradeLevel.equalsIgnoreCase("") || !MainClass.checkDigit(gradeLevel) || Integer.parseInt(gradeLevel) < 1 || Integer.parseInt(gradeLevel) > 5){
            do{
                System.out.print("\nPlease Enter Valid Grade Level to apply filter on timetable lessons :");
                gradeLevel = scanner.nextLine();
            }while(gradeLevel.equalsIgnoreCase("") || !MainClass.checkDigit(gradeLevel) || Integer.parseInt(gradeLevel) < 1 || Integer.parseInt(gradeLevel) > 5);
        }        
        
        TIMETABLE_FILTER_BY_GRADE_LEVEL = Integer.parseInt(gradeLevel) ;
        filteredTimetableLessons();
    }
    
    
    //Filtered Timetable
    public static void filteredTimetableLessons(){
                
        System.out.println("\n\n----------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-10s | %-12s | %-15s | %-10s | %-10s | %-20s |  %-18s |  %-15s | \n",
                "TimetableID","Lesson", "Grade Level","WeekDay","Slot", "InstructedBy","MaxSeats","Date");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
        
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();
        List<Users> userData = Users.getUsersData();
        Set<Integer> uniqueRows = new HashSet<>(); 
        
        for(TimetableLessons obj : timetableLessons){
            if(!uniqueRows.contains(obj.getTimetableID())){
                uniqueRows.add(obj.getTimetableID());
                String coachName = "";
                int age = 0;
                for(Users instructorData : userData){
                    if(obj.getInstructorUserID() == instructorData.getUserID()){
                        coachName = instructorData.getUsername();
                        age = instructorData.getAge();
                        break;
                    }
                }
                if(TIMETABLE_FILTER_BY_GRADE_LEVEL != 0 && obj.getClassGradelevel() == TIMETABLE_FILTER_BY_GRADE_LEVEL){
                    System.out.printf("| %-10s | %-12s | %-15s | %-10s | %-10s | %-20s |  %-18s |  %-15s | \n",
                       obj.getTimetableID(),obj.getLesson(), "Level : "+obj.getClassGradelevel(),obj.getDay(),
                       obj.getSlot(), coachName+"("+age+" yrs old)",obj.getMaxSeatsForLesson(),obj.getLesosnDate());
                }else if(!TIMETABLE_FILTER_BY_DAY.equalsIgnoreCase("") && obj.getDay().equalsIgnoreCase(TIMETABLE_FILTER_BY_DAY)){
                    System.out.printf("| %-10s | %-12s | %-15s | %-10s | %-10s | %-20s |  %-18s |  %-15s | \n",
                       obj.getTimetableID(),obj.getLesson(), "Level : "+obj.getClassGradelevel(),obj.getDay(),
                       obj.getSlot(), coachName+"("+age+" yrs old)",obj.getMaxSeatsForLesson(),obj.getLesosnDate());
                }else if(TIMETABLE_FILTER_BY_INSTRUCTOR != 0 && obj.getInstructorUserID() == TIMETABLE_FILTER_BY_INSTRUCTOR){
                    System.out.printf("| %-10s | %-12s | %-15s | %-10s | %-10s | %-20s |  %-18s |  %-15s | \n",
                       obj.getTimetableID(),obj.getLesson(), "Level : "+obj.getClassGradelevel(),obj.getDay(),
                       obj.getSlot(), coachName+"("+age+" yrs old)",obj.getMaxSeatsForLesson(),obj.getLesosnDate());
                }
            }
        }
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
        
        TIMETABLE_FILTER_BY_GRADE_LEVEL = 0;
        TIMETABLE_FILTER_BY_INSTRUCTOR = 0;
        TIMETABLE_FILTER_BY_DAY = "";
        
        if(Bookings.BOOKING){
            MainClass.inputLessonIDForBooking();
            Bookings.TEMPORARY_BOOKING_ID = "";
        }
        if(Bookings.CHANGE_BOOKING){
            MainClass.inputLessonIDToUpdateBooking();
        }
        return;
    }
    
    
    //Is lesson found
    public static boolean isLessonFound(int timetableID){
        boolean found = false;
        
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();

        for(TimetableLessons obj : timetableLessons){
            if(obj.getTimetableID() == timetableID){
                found = true;
                break;
            }
        }
        return found;
    }
    
    
    
    //getAvailableSeatsd
    public static int getAvailableSeats(int timetableID){
        int seats = 0;
        
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();

        for(TimetableLessons obj : timetableLessons){
            if(obj.getTimetableID() == timetableID){
                seats = obj.getMaxSeatsForLesson();
                break;
            }
        }
        return seats;
    }
    
    
    //decreaseLessonSeatsAvailability
    public static void decreaseLessonSeatsAvailability(int timetableID){
        
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();

        for(TimetableLessons obj : timetableLessons){
            if(obj.getTimetableID() == timetableID){
                obj.setMaxSeatsForLesson(obj.getMaxSeatsForLesson() - 1);
                break;
            }
        }
    }
    
    
    //increaseLessonSeatsAvailability
    public static void increaseLessonSeatsAvailability(int timetableID){
         List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();

        for(TimetableLessons obj : timetableLessons){
            if(obj.getTimetableID() == timetableID){
                obj.setMaxSeatsForLesson(obj.getMaxSeatsForLesson() + 1);
                break;
            }
        }
    }
    
    //Allowed Grade Level
     public static boolean validLessonToBook(int timetableID){
        boolean valid = true;
        
        //User garde
        int LOGGED_IN_ID = Users.LOGGED_IN_ID; 
        List<Users> userData = Users.getUsersData();
        int userGrade = 0;
        for(Users obj : userData){
            if(obj.getUserID() == LOGGED_IN_ID){
                userGrade = obj.getGradeLevel();
                break;
            }
        }
        
        //lesson Grade
        int lessonGrade = 0;
        List<TimetableLessons> timetableLessons = TimetableLessons.getTimetableLessons();
        for(TimetableLessons obj : timetableLessons){
            if(obj.getTimetableID() == timetableID){
                lessonGrade = obj.getClassGradelevel();
                break;
            }
        }
                
        if(lessonGrade > ( userGrade + 1) || lessonGrade < userGrade){
            valid = false;
        }                
        
        return valid;
    }
     
    
    
}
