
package swimmingbookings;


public class ProxyDesignPatttern implements GenerateReport {
    
    
     private ReportsData ReportsData;

    @Override
    public void generateReport() {
        if (ReportsData == null) {
            ReportsData = new ReportsData();
        }
        ReportsData.generateReport();
    }
    
    
}
