

import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;
import swimmingbookings.Bookings;
import swimmingbookings.TimetableLessons;


public class TestFile {
    
   
    @Test
    public void test1gradeTimetable() {
        TimetableLessons.TIMETABLE_FILTER_BY_GRADE_LEVEL = 2;
        TimetableLessons.filteredTimetableLessons();

    }
     
     
   
    @Test
    public void test2makeBooking() {
        int timetableID = 101;
        Bookings.scheduleBooking(timetableID);
        assertTrue(!Bookings.bookingData.isEmpty());
    }
     
     
        
   
    @Test
    public void test3twiceBooking() {
       int timetableID = 101;
        
        //Twice Booking
        boolean isBookingTwiceByLearner = Bookings.isBookingTwiceByLearner(timetableID);
        if(isBookingTwiceByLearner){
            System.out.println("\nTwice Booking");
            return;
        }
        assertTrue(isBookingTwiceByLearner);
    }
     
     
    @Test
    public void test4updateBooking() {
        int newTimetableID = 102;
        Bookings.updateBooking(newTimetableID);
        String bookingStatus = "";

        List<Bookings> bookings = Bookings.getBookingData();

        for(Bookings obj : bookings){
            if(obj.getBookingID().equalsIgnoreCase(Bookings.TEMPORARY_BOOKING_ID) && 
                    obj.getBookingStatus().equalsIgnoreCase(Bookings.CHANGED)){
                bookingStatus = obj.getBookingStatus();
                break;
            }
        }
        System.out.println("Lesson Updated");
        assertTrue(bookingStatus.equalsIgnoreCase(Bookings.CHANGED));
    }
     
    
     
     
    @Test
    public void test5testTocancelBooking() {
        Bookings.cancelBooking();
       
        String bookingStatus = "";
        
        List<Bookings> bookings = Bookings.getBookingData();

        for(Bookings obj : bookings){
            if(obj.getBookingID().equalsIgnoreCase(Bookings.TEMPORARY_BOOKING_ID) && 
                    obj.getBookingStatus().equalsIgnoreCase(Bookings.CANCELLED)){
                bookingStatus = obj.getBookingStatus();
                break;
            }
        }
        assertTrue(bookingStatus.equalsIgnoreCase(Bookings.CANCELLED));
        
    }
     
    
     
     
}
